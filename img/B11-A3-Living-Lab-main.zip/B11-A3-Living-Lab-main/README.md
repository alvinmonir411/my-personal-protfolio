### WELCOME TO ASSIGNMENT-003
<p>You will be assigned a random category. Follow the given category to complete your task accordingly.</p>

# Category-001 :  <img width=40 src="/Assignment_03_Category_0001/c1-assets/logo-header.png"/> PET-SHOP
# Category-002 :  <img width=150 src="/Assignment_03_Category_0002/c2-assets/logo-header.png"/> 

## **📅 Deadline For 60 marks**: 1st February , 2025 ( 11:59 pm ⏱️)

## **📅 Deadline For 50 marks**: 2nd February , 2025 ( 11:59 pm ⏱️)

**📅 Deadline For 30 marks**: Any time after 2nd February.
---
🏆 Requirements
---
Follow your category video strictly to meet all the requirements and Challenges.
